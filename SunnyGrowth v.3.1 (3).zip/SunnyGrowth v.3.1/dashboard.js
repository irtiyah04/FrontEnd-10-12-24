document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('barChart').getContext('2d');
  
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Basic Numbers', 'Basic Animals', 'Human Body', 'Number Practice'],
        datasets: [{
          label: 'Scores',
          data: [98, 35, 76, 85],
          backgroundColor: ['#4caf50', '#f44336', '#ffeb3b', '#42a5f5']
        }]
      },
      options: {
        plugins: {
          title: { display: true, text: 'Quiz Scores per Material' },
          legend: { display: false }
        },
        scales: {
          x: { title: { display: true, text: 'Materials' } },
          y: { beginAtZero: true, title: { display: true, text: 'Scores' } }
        }
      }
    });
  });
  