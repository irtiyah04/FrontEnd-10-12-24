// Fungsi untuk menampilkan preview gambar yang dipilih
function previewProfileImage(event) {
    // Ambil elemen gambar profil
    const profileImage = document.querySelector('.profile-image img');

    // Ambil file yang dipilih oleh pengguna
    const file = event.target.files[0];

    // Cek apakah file ada
    if (file) {
        // Membaca file gambar yang dipilih
        const reader = new FileReader();

        // Ketika file selesai dibaca
        reader.onload = function(e) {
            // Update src gambar profil dengan gambar baru yang dipilih
            profileImage.src = e.target.result;
        };

        // Membaca file sebagai URL
        reader.readAsDataURL(file);
    }
}

// Fungsi untuk memvalidasi dan menyimpan informasi kontak
function saveContactInfo() {
  const form = document.getElementById("contactForm");
  const messageDiv = document.getElementById("contactMessage");

  // Reset pesan sebelumnya
  messageDiv.innerText = "";
  messageDiv.style.color = "red";

  // Validasi form
  if (!form.checkValidity()) {
    messageDiv.innerText = "Please fill out all required fields correctly!";
    return;
  }

  // Jika valid, simpan data dan beri pesan sukses
  messageDiv.style.color = "green";
  messageDiv.innerText = "Contact information saved successfully!";
}

// Fungsi untuk memvalidasi dan menyimpan informasi dasar
function saveBasicInfo() {
  const form = document.getElementById("basicInfoForm");
  const messageDiv = document.getElementById("basicMessage");

  // Reset pesan sebelumnya
  messageDiv.innerText = "";
  messageDiv.style.color = "red";

  // Validasi form
  if (!form.checkValidity()) {
    messageDiv.innerText = "Please fill out all required fields correctly!";
    return;
  }

  // Jika valid, simpan data dan beri pesan sukses
  messageDiv.style.color = "green";
  messageDiv.innerText = "Basic information saved successfully!";
}

// Event listener untuk mencegah form reload halaman
document.getElementById("contactForm").addEventListener("submit", (e) => e.preventDefault());
document.getElementById("basicInfoForm").addEventListener("submit", (e) => e.preventDefault());
